package com.example.hp_pc.myca;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
//implement it is to create a private class inside the Activity-Subclass and let that inner class implement the OnClickListener
public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    //declare the variables
    EditText mEditText, mEditText2;
    Button buttonadd, buttonsub, buttonmul, buttondiv, buttonequal, buttonac;
    Button button1, button2,buttonplus,buttonsum;
    //Button button1,button2,button3,button4,button5,button6,button7,button8,button9,button0;
    TextView textAnswer, textOperator,textv;
    double sum;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //initialise
        //R is a Class in android that are having the id’s of all the view’s.
//findViewById is a method that finds the view from the layout resource file that are attached with current Activity.
        textAnswer = (TextView) findViewById(R.id.textAnswer);
        textOperator = (TextView) findViewById(R.id.textOperator);
        mEditText = (EditText) findViewById(R.id.editText1);
        mEditText2 = (EditText) findViewById(R.id.editText2);
        buttonadd = (Button) findViewById(R.id.buttonadd);
        buttonsub = (Button) findViewById(R.id.buttonsub);
        buttonmul = (Button) findViewById(R.id.buttonmul);
        buttondiv = (Button) findViewById(R.id.buttondiv);
        buttonequal = (Button) findViewById(R.id.buttonequal);
        buttonac = (Button) findViewById(R.id.buttonac);
       // button1 = (Button) findViewById(R.id.button1);
       // button2 = (Button) findViewById(R.id.button2);
       // textv = (TextView) findViewById(R.id.textv);
       // buttonplus =(Button) findViewById(R.id.buttonplus);
      //  buttonsum =(Button) findViewById(R.id.buttonsum);
        //button3 = (Button) findViewById(R.id.button3);
        //button4 = (Button) findViewById(R.id.button4);
        //button5 = (Button) findViewById(R.id.button5);
        //button6 = (Button) findViewById(R.id.button6);
        //button7 = (Button) findViewById(R.id.button7);
        //button8 = (Button) findViewById(R.id.button8);
        //button9 = (Button) findViewById(R.id.button9);
        //button0 = (Button) findViewById(R.id.button0);


//Keyword this refer to the method onclick. It is good to use this way when there are a lot of button in your class file
        buttonadd.setOnClickListener(this);
        buttonsub.setOnClickListener(this);
        buttonmul.setOnClickListener(this);
        buttondiv.setOnClickListener(this);
        buttonequal.setOnClickListener(this);
        buttonac.setOnClickListener(this);
        //button1.setOnClickListener(btnClickListner);
      //  button2.setOnClickListener(btnClickListner);
       // buttonplus.setOnClickListener(btnClickListner);
      //  buttonsum.setOnClickListener(btnClickListner);
    }

    // parseDouble returns a primitive double containing the value of the string(0.0 like point values return)
    //parseDouble() method is used to initialise a STRING (which should contains some numerical value).
    //  and the value it returns is of primitive data type, like int, float, etc.
    //valueOf returns a Double instance, if already cached, you'll get the same cached instance.
    @Override
    //define its definition onClick method
    public void onClick(View v) {
        // onClick you could use view.getId() to get the resource ID
        // then use that in a switch/case block to identify each button and perform the relevant action.
        switch (v.getId()) {

            case R.id.buttonadd:
                sum = Double.parseDouble(String.valueOf(mEditText.getText()))
                        + Double.parseDouble(String.valueOf(mEditText2.getText()));
                textOperator.setText("+");
                break;
            case R.id.buttonsub:
                sum = Double.parseDouble(String.valueOf(mEditText.getText()))
                        - Double.parseDouble(String.valueOf(mEditText2.getText()));
                textOperator.setText("-");
                break;
            case R.id.buttonmul:
                sum = Double.parseDouble(String.valueOf(mEditText.getText()))
                        * Double.parseDouble(String.valueOf(mEditText2.getText()));
                textOperator.setText("*");
                break;
            case R.id.buttondiv:
                sum = Double.parseDouble(String.valueOf(mEditText.getText()))
                        / Double.parseDouble(String.valueOf(mEditText2.getText()));
                textOperator.setText("/");
                break;
            case R.id.buttonac:
                mEditText.setText("");
                mEditText2.setText("");
                textAnswer.setText("");
                textOperator.setText("");
                break;
            case R.id.buttonequal:
                textAnswer.setText(String.valueOf(sum));
                break;


        }
    }

  /*  View.OnClickListener btnClickListner = new OnClickListener() {

        @Override
        public void onClick(View view) {

            if (button1.getId() == view.getId()) {
                textv.setText("\n"+button1.getText().toString());
                textv.setText(button1.getText()+"1");



            }
            else if (button2.getId() == view.getId())
            {
                textv.setText("\n"+button2.getText().toString());
               // textv.setText("\n"+mEditText.getText().toString()+"\n"+mEditText2.getText().toString()+"\nEnd");
            }
            else if (buttonplus.getId() == view.getId())
            {
                textv.setText("\n"+buttonplus.getText().toString());
                // textv.setText("\n"+mEditText.getText().toString()+"\n"+mEditText2.getText().toString()+"\nEnd");
            }
            else if (buttonsum.getId() == view.getId())
            {
                textv.setText("\n"+buttonsum.getText().toString());
                // textv.setText("\n"+mEditText.getText().toString()+"\n"+mEditText2.getText().toString()+"\nEnd");
            }

        }


    };*/
}